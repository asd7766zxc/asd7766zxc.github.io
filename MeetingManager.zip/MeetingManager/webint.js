const readline = require('node:readline');
var { exec } = require('child_process');
const { stdin: input, stdout: output } = require('node:process');



tag = true;
function FireWebsocket(OnAbnormal){
  const socket = new WebSocket("wss://0vbqbul924.execute-api.ap-southeast-2.amazonaws.com/production/")
  
  socket.addEventListener('open', event => {
    console.log('WebSocket connection established!');
    socket.send(JSON.stringify({"action":"sendmessage","message":"onboard"}));
  });
  
  socket.addEventListener('message', event => {
     if(event.data.length){
      console.log('Message from server: ', event.data);
      exec('"meetoggler.exe" '+event.data,function(err,data){
        if(err) {
          console.log(err);
          socket.send(JSON.stringify({"action":"sendmessage","message":"[ERROR] : " + err.message}));
        }
        socket.send(JSON.stringify({"action":"sendmessage","message":data.toString()}));
      });
    }
  });
  
  socket.addEventListener('close', event => {
    console.log('WebSocket connection closed:', event.code, event.reason);
    tag = true;
    if(tag) setTimeout(() => {
        if(tag){
          tag = false;
          FireWebsocket();
        }
      },3);
    return;
  });
  socket.addEventListener('error', error => {
    tag = true;
    socket.close();
  });
  
}
FireWebsocket();