const { exec } = require('child_process');
exec('"meetoggler.exe" 0 1',(err,data) => {
    if(err) {
        console.log(err);
    }
    console.log(data);
});
    