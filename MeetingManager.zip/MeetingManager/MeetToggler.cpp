#include <bits/stdc++.h>
#include <windows.h>
using namespace std;

template<class F, class S> ostream &operator<<(ostream &s, pair<F, S> v) { return s << "(" << v.first << ", " << v.second << ")";} 
template<class F, class S> istream &operator>>(istream &s, pair<F, S> &v) { return s >> v.first >> v.second; }
template<class T> istream &operator>>(istream &s, vector<T> &a) { for (auto &x:a) s>>x; return s; }
template<class T> ostream &operator<<(ostream &s, vector<T> &a) { int n=a.size(); if (!n) return s; s<<a[0]; for (int i=1; i<n; i++) s<<' '<<a[i]; return s; }

#ifdef LOCAL
template<class... T> void dbg(T... x) {
    char e{};
    ((cerr << e << x, e = ' '), ...);
}
#define debug(x...) dbg(#x, '=', x, '\n')
#else
#define debug(...) ((void)0)
#endif

string getTime(){
    std::time_t t = std::time(0);   // get time now
    std::tm* now = std::localtime(&t);
    stringstream ss;
    ss  << (now->tm_year + 1900) << '-' 
        << setfill('0') << setw(2) << (now->tm_mon + 1) << '-'
        << setfill('0') << setw(2) << now->tm_mday << ' '
        << setfill('0') << setw(2) << now->tm_hour << ':'
        << setfill('0') << setw(2) << now->tm_min << ':'
        << setfill('0') << setw(2) << now->tm_sec;
        return ss.str();
}
#define log  "[" << getTime() << "]"
#define INFO " - INFO : "
#define ERRE " - ERRE : "
#define PB push_back
using i64 = long long;

vector<HWND> meetWindows; 
wstring_convert<codecvt_utf8<wchar_t>> utf8;
string getWindowTitle(HWND hwnd){
    int length = GetWindowTextLength(hwnd);
    LPWSTR buffer = new wchar_t[length + 1];
    GetWindowTextW(hwnd, buffer, length + 1);
    return utf8.to_bytes(buffer);
}


void SendShortCut(vector<int> shortCuts){
    INPUT inputs[shortCuts.size() * 2];
    ZeroMemory(inputs,sizeof(inputs));
    int n = shortCuts.size();
    for(int i = 0; i < n;++i){
        inputs[i].type = INPUT_KEYBOARD;
        inputs[i].ki.wVk = shortCuts[i];
    }
    for(int i = 0; i < n;++i){
        inputs[i + n].type = INPUT_KEYBOARD;
        inputs[i + n].ki.wVk = shortCuts[i];
        inputs[i + n].ki.dwFlags = KEYEVENTF_KEYUP;
    }
    UINT uSent = SendInput(ARRAYSIZE(inputs), inputs, sizeof(INPUT));
    if (uSent != ARRAYSIZE(inputs))
    {
        cout << log << ERRE << "Short cuts send failed!!\n";
    } 
}


signed main(int argc, char *argv[])
{
    string str;
    vector<vector<int>> cmds;
    freopen("cmds.txt","r",stdin);

    #pragma region Getting Inputs
    // Get Meeting window handler

    getline(cin,str);
    stringstream ss(str);
    i64 wnds;
    ss >> hex >> wnds;

    getline(cin,str);

    stringstream s1(str);
    int delay_time;
    s1 >> delay_time;
    meetWindows.PB(((HWND)wnds));
    //reset to top
    HWND lastWindow = GetForegroundWindow();

    cout << log << INFO << "Window Base Delay - " << delay_time << '\n';
    cout << log << INFO << "Meeting Window - \n";
    cout << log << INFO << "HWND - " << ((HWND)wnds) << '\n';
    cout << log << INFO <<"Title - " << quoted(getWindowTitle(((HWND)wnds))) << '\n';
    cout << log << INFO << "Last Window - " << lastWindow << '\n';
    int cccnt = 0;
    while(getline(cin,str)){
        ++cccnt;
        stringstream ss(str);
        int c;
        vector<int> tmp;
        if(cccnt <= 3){
            while(ss >> c) tmp.PB(c);
        }else{
            while(ss >> hex >> c) tmp.PB(c);
        }
        cmds.PB(tmp);
    }
    #pragma endregion 
    int cnt = 0;
    vector<int> inds;
    for(int i = 1; i < argc;++i){
        stringstream ss2(argv[i]);
        int indexss = 0;
        while(ss2 >> indexss) inds.PB(indexss);
    }
    if(getWindowTitle(((HWND)wnds)) == "") {
        meetWindows.pop_back();
         for(auto i:inds){
            auto cmd = cmds[i];
            Sleep(delay_time);
            SendShortCut(cmd);
            cout << log << INFO << "Sending Shortcuts - \n";
            cout << log << INFO << cmd <<"\n";
        }
    }
    bool meets = false;
    for(auto c:inds){
        if(c == 0 || c == 1) meets = true;
    }
    if(!meets){
        for(auto i:inds){
            auto cmd = cmds[i];
            Sleep(delay_time);
            SendShortCut(cmd);
            cout << log << INFO << "Sending Shortcuts - \n";
            cout << log << INFO << cmd <<"\n";
        }
    }else{
        for(auto hwnd:meetWindows){
            ShowWindow(hwnd,SW_RESTORE);
            SetForegroundWindow(hwnd);
            for(auto i:inds){
                auto cmd = cmds[i];
                Sleep(delay_time);
                SendShortCut(cmd);
                cout << log << INFO << "Sending Shortcuts - \n";
                cout << log << INFO << cmd <<"\n";
            }
            Sleep(delay_time);
        }
    }
    Sleep(delay_time);
    for(auto c:inds){
        if(c == 2) return 0;
    }
    SetForegroundWindow(lastWindow);
    return 0;    
} 

/*
     /\_/\
    (= ._.)
    / >  \>
*/