#include <bits/stdc++.h>
#include <windows.h>
using namespace std;

template<class F, class S> ostream &operator<<(ostream &s, pair<F, S> v) { return s << "(" << v.first << ", " << v.second << ")";} 
template<class F, class S> istream &operator>>(istream &s, pair<F, S> &v) { return s >> v.first >> v.second; }
template<class T> istream &operator>>(istream &s, vector<T> &a) { for (auto &x:a) s>>x; return s; }
template<class T> ostream &operator<<(ostream &s, vector<T> &a) { int n=a.size(); if (!n) return s; s<<a[0]; for (int i=1; i<n; i++) s<<' '<<a[i]; return s; }

#ifdef LOCAL
template<class... T> void dbg(T... x) {
    char e{};
    ((cerr << e << x, e = ' '), ...);
}
#define debug(x...) dbg(#x, '=', x, '\n')
#else
#define debug(...) ((void)0)
#endif

vector<HWND> meetWindows; 
wstring_convert<codecvt_utf8<wchar_t>> utf8;
wstring pattern = L"microsoft teams";
// string pattern = "notepad";
string getWindowTitle(HWND hwnd){
    int length = GetWindowTextLength(hwnd);
    LPWSTR buffer = new wchar_t[length + 1];
    GetWindowTextW(hwnd, buffer, length + 1);
    return utf8.to_bytes(buffer);
}
// static BOOL CALLBACK enumWindowCallback(HWND hWnd, LPARAM lparam) {
//     int length = GetWindowTextLength(hWnd);
//     // List visible windows with a non-empty title
//     wstring windowTitle = getWindowTitle(hWnd);
//     if (IsWindowVisible(hWnd) && length != 0) {
//         for(int i = 0; i + pattern.size() - 1 < windowTitle.size();++i){
//             int cnt = 0;
//             for(int j = 0; j < pattern.size(); ++j){
//                 if(windowTitle[i + j] == pattern[j]) ++cnt;
//             }
//             if(cnt == pattern.size()){
//                 meetWindows.push_back(hWnd);
//                 return TRUE;
//             }
//         }
//     }
//     return TRUE;
// }
void sendShortCut(HWND hwnd,const vector<int>& shortCutKeys){
    for(auto c:shortCutKeys){
        PostMessage(hwnd,WM_KEYDOWN,c,0);
    }
    for(auto c:shortCutKeys | views::reverse){
        PostMessage(hwnd,WM_KEYUP,c,0);
    }
}

string getTime(){
    std::time_t t = std::time(0);   // get time now
    std::tm* now = std::localtime(&t);
    stringstream ss;
    ss  << (now->tm_year + 1900) << '-' 
        << setfill('0') << setw(2) << (now->tm_mon + 1) << '-'
        << setfill('0') << setw(2) << now->tm_mday << ' '
        << setfill('0') << setw(2) << now->tm_hour << ':'
        << setfill('0') << setw(2) << now->tm_min << ':'
        << setfill('0') << setw(2) << now->tm_sec;
        return ss.str();
}
#define log  "[" << getTime() << "]"
#define INFO " - INFO : "
#define ERRE " - ERRE : "
#define PB push_back
using i64 = long long;


bool FakeKeyInputs(LPINPUT inputs){
    UINT uSent = SendInput(ARRAYSIZE(inputs), inputs, sizeof(INPUT));
    return uSent == ARRAYSIZE(inputs);
}
void SendShortCut(vector<int> shortCuts){
    INPUT inputs[shortCuts.size() * 2];
    ZeroMemory(inputs,sizeof(inputs));
    int n = shortCuts.size();
    for(int i = 0; i < n;++i){
        inputs[i].type = INPUT_KEYBOARD;
        inputs[i].ki.wVk = shortCuts[i];
    }
    for(int i = 0; i < n;++i){
        inputs[i + n].type = INPUT_KEYBOARD;
        inputs[i + n].ki.wVk = shortCuts[i];
        inputs[i + n].ki.dwFlags = KEYEVENTF_KEYUP;
    }
    // while(!FakeKeyInputs(inputs)) Sleep(200);
    UINT uSent = SendInput(ARRAYSIZE(inputs), inputs, sizeof(INPUT));
    if (uSent != ARRAYSIZE(inputs))
    {
        cout << log << ERRE << "Short cuts send failed!!\n";
    } 
}
signed main()
{
    string str;
    vector<vector<int>> cmds;
    freopen("cmds.in","r",stdin);
    // Get Meeting window handler

    getline(cin,str);
    stringstream ss(str);
    i64 wnds;
    ss >> hex >> wnds;

    getline(cin,str);

    stringstream s1(str);
    int delay_time;
    s1 >> delay_time;
    meetWindows.PB(((HWND)wnds));
    cout << log << INFO << "Window Base Delay - " << delay_time << '\n';
    cout << log << INFO << "Meeting Window - \n";
    cout << log << INFO << "HWND - " << ((HWND)wnds) << '\n';
    cout << log << INFO << quoted(getWindowTitle(((HWND)wnds))) << '\n';
    
    while(getline(cin,str)){
        stringstream ss(str);
        int c;
        vector<int> tmp;
        while(ss >> c) tmp.PB(c);
        cmds.PB(tmp);
    }

    vector<int> toggleMute{'M'};  
    //切回簡報  
    HWND lastWindow = GetForegroundWindow();
    int cnt = 0;
    for(auto hwnd:meetWindows){
        ShowWindow(hwnd,SW_RESTORE);
        SetForegroundWindow(hwnd);
        for(auto cmd:cmds){
            // SendShortCut({VK_CONTROL,VK_SHIFT,'M'}); // toggle mute
            // 17 16 77

            // SendShortCut({VK_CONTROL,VK_SHIFT,'O'}); // toggle camera
            // 17 16 79
            Sleep(delay_time);
            SendShortCut(cmd);
            cout << log << INFO << "Sending Shortcuts - \n";
            cout << log << INFO << cmd <<"\n";

        }
        Sleep(delay_time);
    }
    Sleep(delay_time);
    SetForegroundWindow(lastWindow);
    return 0;    
} 

/*
     /\_/\
    (= ._.)
    / >  \>
*/